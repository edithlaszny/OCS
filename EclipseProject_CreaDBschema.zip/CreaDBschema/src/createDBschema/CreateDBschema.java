package createDBschema;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *  the class renames and merges the generated .SQL files
 *  (composed by the project OWLpreprocessing) and upload
 *  the data into the DB... 
 */
public class CreateDBschema 
{
	public static void main(String[] args) 
	{
        try
        {
      	    execCommand("./cmd/createDBschema.sh") ;
        }
        catch(InterruptedException e)
        {
        	e.printStackTrace() ;
        }
		
	}   //  end of method main()
    
    private static void execCommand(String cmd) throws InterruptedException
    {
        try
        {
            ProcessBuilder pb = new ProcessBuilder(cmd) ;

            //  merge stdout and stderr
            pb.redirectErrorStream(true) ;

            Process process = pb.start();

            //  read the output
            try (BufferedReader reader = 
                 new BufferedReader(new InputStreamReader(process.getInputStream()))) 
            {
                String line;
                while ((line = reader.readLine()) != null) 
                {
                    System.out.println(line);
                }
            }
        } 
        catch(IOException e)
        {
            e.printStackTrace() ;
        }
        
    }   //  end of method execCommand()
	
}   //  end of class CreateDBschema
