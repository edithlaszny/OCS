package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GenerateNoHtml_doc 
{
	GenerateNoHtml_doc(String      htmlResult,   //  result file name 
                       Connection  DBconnection  //  DB connections
                      )
	{
        ResultSet rs = new DBFO_DButils().establishResultSet(DBconnection, 
                       "SELECT * FROM HTML_HEADER " +
                       "    WHERE SESSION_ID = 1"   +  
                       " ORDER BY line_num ASC ;") ;
        try 
        {   
        	FileWriter fileWriter = new FileWriter(new File(htmlResult), false) ;

            while (rs.next()) 
            	fileWriter.write(rs.getString("html_cmd") + "\n") ;

            String currTime = new SharedUtils().getCurrTime() ; 
            
        	fileWriter.write(  "<br /><br /><br />" 
        	                 + "<h3><span style=\"color: red;\">HTML doc generating "
        			         + "is disabled</span>.<br /><br />\n") ;
        	fileWriter.write("See DBFOmain.java<br /><br /><br /><br />\n") ;
        	fileWriter.write("(" + currTime + ")</h3>\n") ;
        	
        	fileWriter.write(  "<div class=\"status\">"
                             + "&nbsp; &nbsp; &nbsp; &nbsp; SO &mdash; "
        			         + "Ontology of General Sociology"
                             + "</div>") ;
            /**
             *  closing the result set
             */
            rs.close() ;

            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the result
         */

        
        new DBFO_main().log(new StringBuilder()
                       .append("    asserted  " + 0 + 
                      		   " html lines (html doc generating disabled)\n"
                    		  ).toString() 
                           ) ; 
        
	}   //  end of constructor

}   //  and of class GenerateNoHtml_doc
