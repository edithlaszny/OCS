package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *  The <b><code>WriteOWLTrailer</code></b> class processes 
 *  
 *  <b>Environment:</b>
 *  <ul>
 *  <li>    IDE:              Eclipse IDE for Java Developers
 *  <li>    Version:          2021-12 (4.22.0)
 *  <li>    Build id:         20211202-1639
 *  <li>    HW Model Name:    iMac, MacOS Monterey, 12.5.1
 *  <li>    Processor Name:   Quad-Core Intel Core i5
 *  <li>    Processor Speed:  3.2 GHz
 *  <li>    Memory:           32 GB 1867 MHz DDR3
 *  <li>    Disk:             APPLE SSD SM0256G    
 *  <li>    Serial:           DGKRC080GG7V
 *  </ul>
 *  @version 1-001
 *  @since   2024/05/23
 *  @author  Edit Hlaszny (https://www.edithlaszny.eu/ edithlaszny@gmail.com)
 */ 

public class WriteOWLTrailer 
{
    WriteOWLTrailer(String      OWLresultFile,  //  result file name 
                    Connection  DBconnection    //  active DB connection
                   )
    {
        int            countOfTrailerLines = 0 ;
        DBFO_DButils        dbu                      = new DBFO_DButils() ;
        FileWriter     fileWriter               = null ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT xml_cmd FROM ONTOLOGY_TRAILER ORDER BY trailer_id ASC ;") ;
        try 
        {
            fileWriter = new FileWriter(new File(OWLresultFile), true) ;

            while (rs.next()) 
            {
                fileWriter.write(rs.getString("xml_cmd")) ;

                countOfTrailerLines++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the file writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        new DBFO_main().log(new StringBuilder()
                       .append("    appended  " + countOfTrailerLines + " OWL/XML trailer line(s)\n")
                       .toString()
                           ) ; 
        
    }   //  end of constructor()
    
}   //  end of class WriteOWLTrailer

 