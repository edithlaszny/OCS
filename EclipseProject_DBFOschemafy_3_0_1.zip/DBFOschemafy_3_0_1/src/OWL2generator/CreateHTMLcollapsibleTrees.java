package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateHTMLcollapsibleTrees 
{
    private DBFO_DButils     dbu          = new DBFO_DButils() ;
	private Connection  DBconnection = null ;
    private FileWriter  fileWriter   = null ;
	private String      htmlResult   = "" ;
	
	CreateHTMLcollapsibleTrees(String htmlResult,   //  result file name 
                               Connection  DBconnection  //  DB connections
                              )
    {
        this.DBconnection = DBconnection ;
        this.htmlResult   = htmlResult ; 

        addCollapsibleTrees() ;
        
    }   //  end of constructor()

	private void addCollapsibleTrees()
	{
        try
        {
            this.fileWriter = new FileWriter(new File(this.htmlResult), true) ;

            this.fileWriter.write(
            		"\n<!-- start of \"Data * Structures\" -->\n" +
            		"<div class=\"struct-name\" onclick=\"toggleStruct(this)\">\n" +
            		"    <div class=\"h4p\">Data Structures (4)</div>\n" +
            		"</div>\n" +
            		"<div class=\"struct-details\">\n") ;

            /**
             *  closing the buffered writer
             */
            this.fileWriter.close() ;

            addCollapsibleTree("BFO_TREE",              "BFO 2020 structure") ; 
    	    addCollapsibleTree("SO_TREE",               "SO class structure") ; 
    	    addCollapsibleTree("OBJECT_PROPERTY_TREE",  "SO object property structure") ; 
//    	    addCollapsibleTree("OBJECT_PROPERTY_TREE",  "2 SO object property structure") ; 
    	addDataCollapsibleTree("DATA_PROPERTY_TREE",    "SO data property structure") ; 

            this.fileWriter = new FileWriter(new File(this.htmlResult), true) ;

		    this.fileWriter.write("\n</div> <!-- end of \"Data Structures\" -->\n") ; 		
            
            /**
             *  closing the buffered writer
             */
            this.fileWriter.close() ;
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }
	}
	
	private void addCollapsibleTree(String DBtableName,
			                        String title
			                       )
	{
        int countOfitems = 0 ;
        
        ResultSet rs = dbu.establishResultSet(this.DBconnection, 
                       "SELECT * FROM " + DBtableName + " ORDER BY line_num ASC ;") ;
        try 
        {   
            this.fileWriter = new FileWriter(new File(this.htmlResult), true) ;
        
            this.fileWriter.write("<h2>" + title + "</h2>\n") ;
            this.fileWriter.write("<div class=\"BFOstruct\">\n") ;
            
            /**
             *  there is no owl:topObjectProperty in the tree def file,
             *  this is the reason of this patchwork...         
             */
            if (DBtableName.compareTo("OBJECT_PROPERTY_TREE")  == 0)
            {
                this.fileWriter.write("<details>\n") ;
                this.fileWriter.write("<summary>owl:topObjectProperty</summary>\n") ;
            }
            
            while (rs.next()) 
            {
            	this.fileWriter.write("    " + rs.getString("html_cmd") + "\n") ;
                countOfitems++ ;
            }
            
            this.fileWriter.write("</div>\n<hr />\n") ;
            
            /**
             *  closing the result set
             */
            rs.close() ;

            /**
             *  END OF SECTION MARKER setting 
             */
            String marker = "<!--  END OF SECTION: collapsible items for " 
                            + DBtableName + ")  -->\n\n" ;
            this.fileWriter.write(marker) ;

            /**
             *  closing the buffered writer
             */
            this.fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        } 
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

   		/**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfitems + " html " + 
                              DBtableName + " collapsible tree line(s)\n")
                      .toString()
                 ) ; 
		
	}   //  end of method addCollapsibleTree()

	private void addDataCollapsibleTree(String DBtableName,
                                        String title
                                       )
    {
        int countOfitems = 0 ;
        
        ResultSet rs = dbu.establishResultSet(this.DBconnection, 
                       "SELECT * FROM " + DBtableName + " ORDER BY line_num ASC ;") ;
        try 
        {   
            this.fileWriter = new FileWriter(new File(this.htmlResult), true) ;

            while (rs.next()) 
            {
            	this.fileWriter.write("    " + rs.getString("html_cmd") + "\n") ;
                countOfitems++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;

            /**
             *  END OF SECTION MARKER setting 
             */
            String marker = "\n<!--  END OF SECTION: collapsible items for " 
                            + DBtableName + ")  -->\n\n" ;
            this.fileWriter.write(marker) ;

            /**
             *  closing the buffered writer
             */
            this.fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        } 
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

   		/**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfitems + " html " + 
                              DBtableName + " collapsible tree line(s)\n")
                      .toString()
                 ) ; 
		
    }   //  end of method addDataCollapsibleTree() 
	
}   //  end of class CreateHTMLcollapsibleTrees
