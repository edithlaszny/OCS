package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateHtmlHeaderDynamicPart 
{
	CreateHtmlHeaderDynamicPart(String      htmlResult,   //  result file name 
                          Connection  DBconnection  //  DB connections
                         )
    {
        int         countOfHtmlHdrLines = 0 ;
        DBFO_DButils     dbu                 = new DBFO_DButils() ;
        FileWriter  fileWriter          = null ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM ONTOLOGY_HEADER_ANNOTATIONS" +  
                       " ORDER BY hdrAnn_id ASC ;") ;
        try 
        {   fileWriter = new FileWriter(new File(htmlResult), true) ;
        
            while (rs.next()) 
            {
            	String title = removePrefixAndCapitalize(rs.getString("iri")) ;
            	String value = rs.getString("literal") ;
            	
            	if (title.compareTo("Created") == 0)
            		value = getCurrTime() ;
            	else if (title.compareTo("HasVersion") == 0)
            		title = "Version" ;
            	else if (title.compareTo("Creator") == 0)
            		title = "Author" ;
            	else if (title.compareTo("Mbox") == 0)
            		title = "eMail" ;
            	else if (title.compareTo("UDC") == 0)
            		title = "UDC (Universal Decimal Classification)" ;
            	else if (title.compareTo("Homepage") == 0)
            		value = "<a href=\"" + value + "\" target=\"_blank\">" + value + "</a>" ;
            	else ;
            	
            	String htmlSnippet = "                <dt>" + title + "</dt>\n" +
                                     "                    <dd>" + value + "</dd>\n" ; 
            	fileWriter.write(htmlSnippet) ;
                countOfHtmlHdrLines++ ;
            }
          
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfHtmlHdrLines + 
                    		  " html header line(s) in dynamic part\n")
                      .toString()
                 ) ; 
    	
    }   //  end of constructor()
	
    private String removePrefixAndCapitalize(String input) 
    {
        if (input == null) 
        	return null;

        int colonIndex = input.indexOf(':') ;

        String result = (colonIndex != -1 && colonIndex < input.length() - 1)
                        ? input.substring(colonIndex + 1)
                        : input ;

        if (result.isEmpty()) 
        	return result;

        return result.substring(0, 1).toUpperCase() + result.substring(1);
    }
    
    private String getCurrTime() 
    {
    	String format = "yyyy-MM-dd HH:mm:ss.SSS" ;
    	return new SimpleDateFormat(format).format(new Date()) ;
    	
    }   //  end of method getCurrTime()
    
}   //  end of class CreateHtmlDynamicPart
