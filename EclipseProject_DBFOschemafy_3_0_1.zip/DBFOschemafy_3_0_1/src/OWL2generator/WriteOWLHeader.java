package OWL2generator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *  The <b><code>WriteOWLHeader</code></b> class processes a user-defined
 *  header file fragment (<code>xlmns</code>-definitions, and prefixes
 *  for the <code>dc</code>, <code>obo</code>, <code>owl</code>,
 *  <code>rdf</code>, <code>xml</code>, <code>xsd</code>, 
 *  <code>foaf</code>, <code>rdfs</code> ontologies), and an OWL
 *  base URI to generate the header section of an OWL/XML ontology.
 *  This class is responsible for creating the initial structure of
 *  the OWL ontology file, including essential namespace bindings,
 *  prefix definitions, and ontology metadata. It relies on a
 *  separate file containing preparatory annotations but contributes
 *  significantly to the overall ontology generation process.
 *  <p>
 *  <b>Key Functionalities:</b>
 *  <p>
 *  Reads Pre-defined Header Data: Reads a text file containing
 *  lines with <code>IRI</code> and <code>LITERAL</code> pairs
 *  to create annotations.
 *  <p>
 *  Processes Header Annotations: Parses each line in the header
 *  file, separating <code>IRI</code> and literal values.
 *  <p>
 *  Generates OWL Annotation Tags: Creates corresponding OWL
 *  <code>&lt;Annotation&gt;</code> tags for each <code>IRI</code>-literal
 *  pair.
 *  <p>
 *  Writes OWL Header: Writes the OWL header section to the output
 *  ontology file, including namespace declarations, prefix definitions,
 *  and the ontology <code>IRI</code>.
 *  <p>
 *  Handles I/O Operations: Manages file reading and writing operations.
 *  <p>
 *  Error Handling: Includes basic error handling for missing required
 *  parameters and file I/O exceptions.
 *  <p>
 *  <b>Additional Notes:</b>
 *  <p>
 *  The class assumes a pre-defined file format for the header data.
 *  <p>
 *  The base URI for the ontology is provided as an argument during object creation. 
 *  <p>
 *  <b>Environment:</b>
 *  <ul>
 *  <li>    IDE:              Eclipse IDE for Java Developers
 *  <li>    Version:          2021-12 (4.22.0)
 *  <li>    Build id:         20211202-1639
 *  <li>    HW Model Name:    iMac, MacOS Monterey, 12.5.1
 *  <li>    Processor Name:   Quad-Core Intel Core i5
 *  <li>    Processor Speed:  3.2 GHz
 *  <li>    Memory:           32 GB 1867 MHz DDR3
 *  <li>    Disk:             APPLE SSD SM0256G    
 *  <li>    Serial:           DGKRC080GG7V
 *  </ul>
 *  @version 1-001
 *  @since   2024/05/23
 *  @author  Edit Hlaszny (https://www.edithlaszny.eu/ edithlaszny@gmail.com)
 */ 

public class WriteOWLHeader 
{
    WriteOWLHeader(String      OWLresultFile,  //  result file name 
                   Connection  DBconnection
                  )
    {
        int            countOfXMLhdrLines = 0 ;
        DBFO_DButils        dbu                = new DBFO_DButils() ;
        BufferedWriter buffWriter         = null ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM ONTOLOGY_HEADER ORDER BY hdr_id ASC ;") ;
        try 
        {
            buffWriter = new BufferedWriter(new FileWriter(OWLresultFile)) ;

            while (rs.next()) 
            {
                buffWriter.write(rs.getString("xml_cmd") + "\n") ;
                countOfXMLhdrLines++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the buffered writer
             */
            buffWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfXMLhdrLines + " XML header line(s)\n")
                      .toString()
                 ) ; 
    	
    }   //  end of constructor()
    
}   //  end of class WriteOWLHeader
