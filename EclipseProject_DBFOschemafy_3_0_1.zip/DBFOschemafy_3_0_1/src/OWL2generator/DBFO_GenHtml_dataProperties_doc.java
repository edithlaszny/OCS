package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.ListIterator;

public class DBFO_GenHtml_dataProperties_doc 
{
    private DBFO_DButils     dbu          = new DBFO_DButils() ;
    private Connection  DBconnection = null ;
	
    DBFO_GenHtml_dataProperties_doc(String      htmlResult,   //  result file name 
                                    Connection  DBconnection  //  DB connections
                                   )
    {
		this.DBconnection = DBconnection ;
		
        int        countOfDataProperties = 0 ;
        FileWriter fileWriter            = null ;

        try 
        { 
            ArrayList<TypeOf_DataProperty> dataProperties = dbu.getListOfDataProperties(this.DBconnection) ;
            int numofDataProps =           dataProperties.size();
            
            fileWriter = new FileWriter(new File(htmlResult), true) ;

            fileWriter.write("<div class=\"class-name\" onclick=\"toggleDetails(this)\">\n") ;
                fileWriter.write("    <div class=\"h4p\">Data Properties (" + numofDataProps + ")</div>\n") ;
            fileWriter.write("</div>\n") ;

            fileWriter.write("<!-- start of outer drop down window content -->\n") ;
            fileWriter.write("<div class=\"class-details\">\n") ;  
            
            generateSelectorTable(fileWriter) ;

            ListIterator<TypeOf_DataProperty> itr = dataProperties.listIterator();            
            
            while (itr.hasNext())
            {
            	TypeOf_DataProperty dp = itr.next() ;

            	fileWriter.write(compileDataPropDoc(dp) + "\n") ;
            	
            	/*
                System.out.println(dp.data_property_ID            ) ;
                System.out.println(dp.data_property_IRI           ) ;
                System.out.println(dp.data_property_type          ) ;
                System.out.println(dp.data_property_annotationtype) ;
                System.out.println(dp.super_data_property_IRI     + "\n") ;
            	*/
                //  fileWriter.write(compileObjPropDoc(itr.next())) ;
                countOfDataProperties++ ;
            }
            
            fileWriter.write("</div>\n") ;
    
            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfDataProperties + 
                    		  " html data property(ies)\n")
                      .toString()  
                 ) ; 
    	
    }   //  end of constructor()

	
	private String compileDataPropDoc(TypeOf_DataProperty dp)
	{
        String quickSelectAddress = "<a name=\"" 
                + getQuickSelectAddress(dp.data_property_IRI) + "\">" ;
        
        String decoratedDataPropName = decorateDataPropName(dp.data_property_IRI) ;
        
        
        String htmlCmd = quickSelectAddress +
        "<a name=\"" + dp.data_property_IRI  +  "\">\n" +
        
        "<span style=\"font-size: 4px;line-height: 4px;\"><p /></span>\n" +

        "<div class=\"class-name\" onclick=\"toggleDetails(this)\">\n" +
        "    <div class=\"custom-link-box\">\n" +
        "        <h3>\n" +
        "            <a href=\"#top\"><b>&uarr;</b></a>&nbsp;" 
                        + decoratedDataPropName + "\n" + 
        "        </h3>\n" +
        "    </div>\n" +
        "</div>\n"     + 
        "<div class=\"class-details\">" +
        "    <b>Annotation:</b> " + dp.data_property_annotationtype + "\n" +
        "        <span class=\"smallest\"><br /></span>            \n" +
        
        "    <b>Annotation source:</b> (editor)                    \n" + 
        "        <span class=\"smallest\"><br /></span>            \n" +

        "    <b>Data property type:</b> " + dp.data_property_type  + "\n" + 
        "        <span class=\"smallest\"><br /></span>            \n" +
        
        "    <b>Language:</b> en \n" +
        "        <span class=\"smallest\"><br /></span>            \n"  +

        "    <b>Super data property:</b> " + dp.super_data_property_IRI  + "\n" +
        "        <span class=\"smallest\"><br /></span>            \n" +

        "    <b>Sub-data property:</b> &mdash; \n" +
        "</div>\n" ;

        return htmlCmd ;
		
	}   //  end of method compileDataPropDoc()
	
	private String decorateDataPropName(String dataPropName)
	{
		int    selectorIdx = dataPropName.indexOf("_") ;
		String prefix      = dataPropName.substring(0, selectorIdx) ;
		String suffix      = dataPropName.substring(selectorIdx, dataPropName.length()) ;
		
		return prefix + "<i>" + suffix + "</i>" ; 
		
	}   //  end of method decorateDataPropName
	
    private void generateSelectorTable(FileWriter fileWriter) throws IOException
    {
        fileWriter.write("<table border=\"0\" cellspacing=\"0px\" cellpadding=\"0px\">") ;
        fileWriter.write("<tr class=\"TOC\">") ;

        //                   A               Z
        for (int anchor = 0x41 ; anchor <=0x5A ; anchor++)
        {
        	char letter = (char)anchor ;
        	String address = Character.toString(letter) ;

            if      (address.compareTo("A") == 0) address = "_" ;
            else if (address.compareTo("B") == 0) address = "_" ;
            else if (address.compareTo("F") == 0) address = "_" ;
            else if (address.compareTo("H") == 0) address = "_" ;
            else if (address.compareTo("I") == 0) address = "_" ;
            else if (address.compareTo("J") == 0) address = "_" ;
            else if (address.compareTo("K") == 0) address = "_" ;
            else if (address.compareTo("L") == 0) address = "_" ;
            else if (address.compareTo("M") == 0) address = "_" ;
            else if (address.compareTo("N") == 0) address = "_" ;
            else if (address.compareTo("O") == 0) address = "_" ;
            else if (address.compareTo("P") == 0) address = "_" ;
            else if (address.compareTo("U") == 0) address = "_" ;
            else if (address.compareTo("V") == 0) address = "_" ;
            else if (address.compareTo("W") == 0) address = "_" ;
            else if (address.compareTo("X") == 0) address = "_" ;
            else if (address.compareTo("Y") == 0) address = "_" ;
            else if (address.compareTo("Z") == 0) address = "_" ;
        	
        	fileWriter.write("\n    <td valign=\"bottom\"><div class=\"custom-link-box\">" + 
                             "<a href=\"#" + address + "_dp\"><h3>&nbsp;" + address + 
                             "&nbsp;</h3></a></div></div></td>") ;
        }
        
        fileWriter.write("\n</tr>") ;
        fileWriter.write("\n</table>\n") ;
        fileWriter.write("<span style=\"line-height: 8px;\"><br /></span>\n\n") ;
        
    }   //  end of method generateSelectorTable()

    private String getQuickSelectAddress(String dataPropName)
    {
        if (dataPropName.compareTo("classification_CategoryCode"    ) == 0) return "C_dp" ;
        if (dataPropName.compareTo("demographic_BirthRateValue"     ) == 0) return "D_dp" ;
        if (dataPropName.compareTo("economic_BudgetAllocation"      ) == 0) return "E_dp" ;
        
        // missing 1st letter of data property name 
        
        if (dataPropName.compareTo("geographic_AreaSize"            ) == 0) return "G_dp" ;
        
        // missing 1st letter of data property name 
        
        if (dataPropName.compareTo("quantitative_ConcentrationIndex") == 0) return "Q_dp" ;
        if (dataPropName.compareTo("research_ConfidenceLevel"       ) == 0) return "R_dp" ;
        if (dataPropName.compareTo("socialMeasurement_CapitalScore" ) == 0) return "S_dp" ;
        if (dataPropName.compareTo("temporal_AgeAtEvent"            ) == 0) return "T_dp" ;
        
        // missing 1st letter of data property name         
        
        return "" ;
        
    }   //  end of method getQickSelectAddress()
    
}   //  end of class DBFO_GenHtml_dataProperties_doc 
