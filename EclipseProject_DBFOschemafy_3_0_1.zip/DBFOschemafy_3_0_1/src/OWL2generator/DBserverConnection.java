package OWL2generator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//  https://dev.mysql.com/doc/connectors/en/connector-j-usagenotes-connect-drivermanager.html

public class DBserverConnection
{
    private Connection conn = null ;
    
    public void connectDB(String url  ,
                          String user ,
                          String password) 
    {
        try 
        {
            this.conn = DriverManager.getConnection(url, user, password) ;
        } 
        catch (SQLException ex) 
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: "     + ex.getSQLState());
            System.out.println("VendorError: "  + ex.getErrorCode());
            
            ex.printStackTrace();
        }              
        
    }  //  end of method connectDB()

    
    public  Connection getDBconnector()
    {
        return this.conn ;
        
    }   //  end of method getDBconnector()

}   //  end of class DBserverConnection
