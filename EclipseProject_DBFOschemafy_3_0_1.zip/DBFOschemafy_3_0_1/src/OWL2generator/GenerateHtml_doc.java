package OWL2generator;

import java.sql.Connection;

public class GenerateHtml_doc 
{
	GenerateHtml_doc(String      htmlResult,   //  result file name 
                     Connection  DBconn        //  DB connections
                    )
    {
        final int hdrPart_1 = 1 ;
        final int hdrPart_2 = 2 ;

        new RelationsFetcher(                                             DBconn) ;
        new CreateHtmlHeader(                      htmlResult, hdrPart_1, DBconn) ;
        new CreateHtmlHeaderDynamicPart(           htmlResult,            DBconn) ;
        new CreateHtmlHeader(                      htmlResult, hdrPart_2, DBconn) ;
        new CreateHTMLcollapsibleTrees(            htmlResult,            DBconn) ;
    	new GenerateHtml_class_doc(                htmlResult,            DBconn) ;
    	new DBFO_GenHtml_objProperties_doc(        htmlResult,            DBconn) ;
    	new DBFO_GenHtml_dataProperties_doc(       htmlResult,            DBconn) ;
    	new DBFO_GenHtml_n_ary_CasualRelationships(htmlResult,            DBconn) ;
    	new CreateHtmlTrailer(                     htmlResult,            DBconn) ;

    }   //  end of constructor
	
}   //  end of class GenerateHtml_doc 
	