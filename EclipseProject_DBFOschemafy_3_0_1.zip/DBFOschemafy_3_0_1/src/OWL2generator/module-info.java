module OWL2generator 
{
    requires java.sql;   
}