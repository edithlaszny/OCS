package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeclareIAOAannotations
{
    DeclareIAOAannotations(String      OWLresultFile,  //  result file name 
                           Connection  DBconnection
                          )
    {
        int            countOfIAOAAnnotations = 0 ;
        DBFO_DButils        dbu                   = new DBFO_DButils() ;
        FileWriter     fileWriter            = null ;
        SharedUtils    shu                   = new SharedUtils() ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM IAO_ANNOTATIONS ;") ;
        try 
        {
            fileWriter = new FileWriter(new File(OWLresultFile), true) ;

            while (rs.next()) 
            {
                
                fileWriter.write(shu.declareIAOannotation(rs.getString("abbreviated_IRI")
                                                     )
                                ) ;
                countOfIAOAAnnotations++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the file writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    declared  " + countOfIAOAAnnotations + " IAOA annotation(s)\n")
                      .toString()
                 ) ; 
    }   //  end of constructor()
        
}   //  end of class DeclareIAOAannotations
