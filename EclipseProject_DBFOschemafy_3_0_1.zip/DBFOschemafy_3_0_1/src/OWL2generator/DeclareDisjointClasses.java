package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeclareDisjointClasses
{
    private DBFO_DButils dbu               = new DBFO_DButils() ;
    private FileWriter   fileWriter        = null ;
    /**
     *  W3C-defined separator between IRI and unique variable name
     */
    private final static String SEPARATOR  = "#" ;
    
    DeclareDisjointClasses(String      OWLresultFile,  //  result file name 
                           Connection  DBconnection
                          )
    {
        int       countOfDisjointClassGroups = 0 ;
        ResultSet curr_disjoint_group        = null ;
        int       numofDisjointClassGroups   = getNumofDisjointClassGroups(DBconnection) ;
        
        for (int disjoint_group_id = 1 ; 
                 disjoint_group_id <= numofDisjointClassGroups ;
                 disjoint_group_id++
            )
        {
            curr_disjoint_group = getClassesToDisjoint(DBconnection,
                                                       disjoint_group_id 
                                                      ) ;
            declareClassesToDisjoint(OWLresultFile,      //  output file
                                     DBconnection,       //  connection to the DB
                                     curr_disjoint_group //  classes to be declared to disjunct
                                    ) ;   

            countOfDisjointClassGroups++ ;
        }

        try
        {
            curr_disjoint_group.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    declared  " + countOfDisjointClassGroups + " disjoined class group(s)\n")
                      .toString()
                 ) ; 
        
     }   //  end of constructor()

    private int getNumofDisjointClassGroups(Connection  DBconnection
                                           )
    {
        int       numofDisjointClassGroups = -1 ;
        
        ResultSet rs = this.dbu.establishResultSet(DBconnection, 
                       "SELECT MAX(disjoint_group_id) FROM DISJOINT_OWL_CLASSES ;") ;
        try 
        {
            if (rs.next())
                numofDisjointClassGroups = rs.getInt(1) ;
            
            rs.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }

        return numofDisjointClassGroups ;
        
    }   //  end of getNumofDisjointClassGroups()

    private ResultSet getClassesToDisjoint(Connection  DBconnection,
                                           int         disjoint_group_id 
                                        )
    {
        ResultSet rs = this.dbu.establishResultSet(DBconnection, 
            "SELECT owl_class_IRI FROM DISJOINT_OWL_CLASSES " +
             "WHERE disjoint_group_id = " + disjoint_group_id
                                                  ) ;
        return rs ;
        
    }   //  end of getNumofDisjointClassGroups()

    private void declareClassesToDisjoint(String      OWLresultFile,
                                          Connection  DBconnection,
                                          ResultSet   curr_disjoint_group
                                         )
    {
        try 
        {
            fileWriter = new FileWriter(new File(OWLresultFile), true) ;
            
            fileWriter.write("    <DisjointClasses>\n") ;

            while (curr_disjoint_group.next()) 
            {
                fileWriter.write("        <Class IRI=\"" + SEPARATOR +
                                 curr_disjoint_group.getString("owl_class_IRI") +
                                  "\"/>\n" 
                                ) ;
            }

            fileWriter.write("    </DisjointClasses>\n") ;
            
            /**
             *  closing the result set
             */
            curr_disjoint_group.close() ;
            
            /**
             *  closing the file writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

    }   //  end of ()

}   //  end of class DeclareDisjointClasses
