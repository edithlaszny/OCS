package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateHtmlHeader 
{
	CreateHtmlHeader(String      htmlResult,   //  result file name 
			         int         session_id,   //  hdr is splitted into 2 parts
                     Connection  DBconnection  //  DB connections
                    )
    {
        int          countOfHtmlHdrLines = 0 ;
        DBFO_DButils dbu                 = new DBFO_DButils() ;
        FileWriter   fileWriter          = null ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM HTML_HEADER " +
                       "    WHERE SESSION_ID = " + session_id +  
                       " ORDER BY line_num ASC ;") ;
        try 
        {   
        	/**
             *   1st session > creating the file
             */
        	if (session_id == 1) 
                fileWriter = new FileWriter(new File(htmlResult), false) ;
        	else
                fileWriter = new FileWriter(new File(htmlResult), true) ;

            while (rs.next()) 
            {
            	fileWriter.write(rs.getString("html_cmd") + "\n") ;
                countOfHtmlHdrLines++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;

        	String marker = "\n<!--  END OF SECTION: html header (session = " 
                     + session_id + ")  -->\n\n" ;
        	fileWriter.write(marker) ;
            
            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        new DBFO_main().log(new StringBuilder()
                      .append("    asserted  " + countOfHtmlHdrLines + 
                    		  " html header line(s) in session " + session_id + "\n")
                      .toString()
                           ) ; 
    	
    }   //  end of constructor()
    
}   //  end of class CreateHTMLheader
