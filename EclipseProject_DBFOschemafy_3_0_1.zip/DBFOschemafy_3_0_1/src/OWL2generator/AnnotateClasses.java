package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AnnotateClasses
{
    private DBFO_DButils dbu = new DBFO_DButils() ;
    
    AnnotateClasses(String      OWLresultFile,  //  result file name 
                    Connection  DBconnection    //  active DB server connection
                   )
    {
        int         countOfannotatedClasses = 0 ;
        SharedUtils shu                     = new SharedUtils() ;

        ResultSet rs = this.dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM CLASS_ANNOTATIONS ORDER BY class_IRI ;") ;
        try
        { 
            String     annotation = "" ;
            FileWriter fileWriter = new FileWriter(new File(OWLresultFile), true) ;

            fileWriter.write("\n    <!--  add OWL class annotations\n      -->\n") ;

            while (rs.next()) 
            {
                if (rs.getString("annotation_type_IRI").equals("#BFO_URI"))
                {
                    annotation = dbu.decodeBFOentityMeaning(DBconnection,
                                                            rs.getString("annotation")) ;
                }
                else
                {
                    annotation = rs.getString("annotation") ;
                }
                
                fileWriter.write(shu.assertClassAnnotation(rs.getString("class_IRI")           ,
                                                           rs.getString("annotation_type_IRI") ,
                                                           rs.getString("language")            ,
                                                           annotation
                                                          )
                                ) ;
                
                countOfannotatedClasses++ ;
            }
        
            //  closing the result set
            rs.close() ;
            
            //  closing the file writer
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfannotatedClasses + " class annotation(s)\n")
                      .toString()
                 ) ; 
        
     }   //  end of constructor()

    
}   //  end of class AnnotateClasses
