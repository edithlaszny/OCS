package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeclareClasses
{
    DeclareClasses(String      OWLresultFile,  //  result file name 
                   Connection  DBconnection
                  )
    {
        int            countOfclassDeclarations = 0 ;
        DBFO_DButils   dbu                      = new DBFO_DButils() ;
        FileWriter     fileWriter               = null ;
        SharedUtils    shu                      = new SharedUtils() ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT class_IRI, superclass_of_IRI FROM OWL_CLASSES ORDER BY class_IRI ASC ;") ;
        try 
        {
            fileWriter = new FileWriter(new File(OWLresultFile), true) ;
            
            fileWriter.write("\n    <!--  add OWL class declarations\n      -->\n") ;
            
            while (rs.next()) 
            {
                String superclass_of_IRI = rs.getString("superclass_of_IRI") ;

                /**
                 *  avoid double declarations of OWL classes
                 */
            	if (superclass_of_IRI.substring(0, 4).compareTo("BFO_") != 0)
            	{
                    fileWriter.write(shu.declareClass(rs.getString("class_IRI"))) ;
            	}
                
                countOfclassDeclarations++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the file writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    declared  " + countOfclassDeclarations + " OWL class(es)\n")
                      .toString()
                 ) ; 
    }   //  end of constructor()
        
}   //  end of class DeclareClasses
