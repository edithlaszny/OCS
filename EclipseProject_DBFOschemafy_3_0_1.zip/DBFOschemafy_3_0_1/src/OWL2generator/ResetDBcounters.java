package OWL2generator;

import java.sql.Connection;

public class ResetDBcounters 
{
    private DBFO_DButils dbu = new DBFO_DButils() ;

    ResetDBcounters(Connection conn)    //  active DB connection
	{
    	dbu.DBupdate(conn, "UPDATE OWL_CLASSES SET class_individual_count = 0") ;
    	
	}   //  end of constructor
	
}   //  end of class ResetDBcounters
