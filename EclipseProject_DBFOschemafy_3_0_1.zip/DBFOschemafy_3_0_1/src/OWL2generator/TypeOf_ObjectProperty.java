package OWL2generator;

import java.util.ArrayList;

public class TypeOf_ObjectProperty 
{
	String object_property_IRI         = "" ;
	String annotation                  = "" ;
	String annotation_type_IRI         = "" ;
	String language                    = "" ;
	String inverse_object_property_IRI = "" ;
	String super_object_property_IRI   = "" ;
	String sub_object_property_IRI     = "" ;
	
	ArrayList<String>             listOfsubObjProperties =  null ;
    ObjectPropertyCharacteristics opc                    = null ; 
    
    TypeOf_ObjectProperty() 
    {
    	this.opc = new ObjectPropertyCharacteristics() ; 
    	
    }   //  end of constructor

    class ObjectPropertyCharacteristics
    {
        /*
         *  because of simplicity no getter/setter will be used
         */
        boolean ch_functional        = false ;
        boolean ch_inverseFunctional = false ;
        boolean ch_symmetric         = false ;
        boolean ch_asymmetric        = false ;
        boolean ch_transitive        = false ;
        boolean ch_reflexive         = false ;
        boolean ch_irReflexive       = false ;
        
        ObjectPropertyCharacteristics()
        { ; }

    }   //  end of inner-inner class ObjectPropertyCharacteristics

}   //  end of class TypeOf_ObjectProperty
