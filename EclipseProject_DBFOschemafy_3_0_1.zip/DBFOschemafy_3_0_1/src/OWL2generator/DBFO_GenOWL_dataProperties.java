package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.util.ListIterator;

public class DBFO_GenOWL_dataProperties 
{
    private DBFO_DButils     dbu = new DBFO_DButils() ;
    private SharedUtils shu = new SharedUtils() ;
	
    DBFO_GenOWL_dataProperties(String      OWLresultFile,  //  result file name 
                               Connection  DBconnection  //  DB connections
                              )
    {
        int         countOfDataProperties = 0 ;
        FileWriter  fileWriter           = null ;

        try 
        { 
            fileWriter = new FileWriter(new File(OWLresultFile), true) ;

            ListIterator<TypeOf_DataProperty> itr =  dbu
            		                                  .getListOfDataProperties(DBconnection)
            		                                  .listIterator();            
            while (itr.hasNext())
            {
            	fileWriter.write(shu.declareDataPropertyData(itr.next())) ;
            	countOfDataProperties++ ;
            }
    
            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        new DBFO_main().log(new StringBuilder()
                      .append("    asserted  " + countOfDataProperties + 
                    		  " OWL/XML encoded data property(ies)\n")
                      .toString()  
                 ) ; 
    	
    }   //  end of constructor()

}   //  end of class DBFO_GenOWL_objProperties 
