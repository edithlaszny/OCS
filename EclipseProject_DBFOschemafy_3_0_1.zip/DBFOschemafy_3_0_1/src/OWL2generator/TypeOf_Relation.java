package OWL2generator;

import java.util.ArrayList;

public class TypeOf_Relation 
{
	int    n_ary_relation_id ;
    String predicate ;
    String relationName ;
    String relationAnnotation ;
    String causal_event_indiv ;
    
    ArrayList<RelationMemberData> subject ;
    ArrayList<RelationMemberData> object ;
    
    public TypeOf_Relation() 
    {
        subject = new ArrayList<>() ;
        object  = new ArrayList<>() ;
        
    }   //  end of inner class parseRelationMemberData

    public class RelationMemberData 
    {
        String OWLclassName ;      // subject or object class name
        String dataPropertyName ;
        String dataPropertyValue ;
        int    n_ary_relation_id ;
        int    participant_id ;
    
    }   //  end of class RelationMemberData

}   //  end of class TypeOf_Relation
