package OWL2generator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateHtmlTrailer 
{
	CreateHtmlTrailer(String      htmlResult,   //  result file name 
                      Connection  DBconnection  //  DB connections
                     )
    {
        int         countOfHtmlTrailerLines = 0 ;
        DBFO_DButils     dbu                 = new DBFO_DButils() ;
        FileWriter  fileWriter          = null ;
        
        ResultSet rs = dbu.establishResultSet(DBconnection, 
                       "SELECT * FROM HTML_TRAILER ORDER BY line_num ASC ;") ;
        try 
        {   /**
             *   1st session > creating the file
             */
           fileWriter = new FileWriter(new File(htmlResult), true) ;
        	
            while (rs.next()) 
            {
            	fileWriter.write(rs.getString("html_cmd") + "\n") ;
                countOfHtmlTrailerLines++ ;
            }
            
            /**
             *  closing the result set
             */
            rs.close() ;
            
            /**
             *  closing the buffered writer
             */
            fileWriter.close() ;
        }
        catch(SQLException SQLex)
        {
            System.out.println("Cannot connect the database") ;
            System.out.println("SQLException: " + SQLex.getMessage());
            System.out.println("SQLState: "     + SQLex.getSQLState());
            System.out.println("VendorError: "  + SQLex.getErrorCode());

            SQLex.printStackTrace();
        }
        catch(IOException IOex)
        {
            IOex.printStackTrace() ;
        }

        /**
         *  Logging of the output volume
         */
        DBFO_main OWL2G = new DBFO_main() ;
        
        OWL2G.log(new StringBuilder()
                      .append("    asserted  " + countOfHtmlTrailerLines + 
                    		  " html trailer line(s)\n")
                      .toString()
                 ) ; 
    	
    }   //  end of constructor()
    
}   //  end of class CreateHTMLheader
