package OWL2generator;

public class TypeOf_DataProperty 
{
	
    int    data_property_ID              =  0 ;
    String data_property_IRI             = "" ;
    String data_property_type            = "" ;
    String data_property_annotationtype  = "" ;
    String super_data_property_IRI       = "" ;

}   //  end of class TypeOf_DataProperty

