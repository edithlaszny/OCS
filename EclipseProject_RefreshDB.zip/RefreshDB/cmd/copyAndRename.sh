#!/bin/bash
#
# copyAndRename.sh
#
# Simple script: rename <base>.sql.txt -> <base>.sql and concatenate them in order.
# Environment: bash

set -euo pipefail

echo ""
echo "--------  Project RefresDB7

--------"
echo "--------  DBFOsociology: DB content actualising  --------"
echo ""

SRC_DIR="../OWLpreprocessing/output"
SQL_DIR="../OWLpreprocessing/sql"
OUT_FILE="${SQL_DIR}/_DBFOsociology.sql"

# Ordered list of base filenames (no extensions)
#
# sibling disjointnesses have been restless removed
#     "SO_upload_06_disjoint_classes"
#
files=(
  "SO_create_00_DBFOsociology"
  "SO_upload_01_XMLheader"
  "SO_upload_02_headerAnnotations"
  "SO_upload_03_skosAnnotations"
  "SO_upload_04_owl_classes"
  "SO_upload_05_BFO_subclasses"
  "SO_upload_06_disjoint_classes"
  "SO_upload_07_class_annotations"
  "SO_upload_08_HTMLheader"
  "SO_upload_09_HTMLtrailer"
  "SO_upload_10_BFO_Tree"
  "SO_upload_11_SO_Tree"
  "SO_upload_12_objPropAnn"
  "SO_upload_13_invObjProp"
  "SO_upload_14_superObjProp"
  "SO_upload_15_objProp_Tree"
  "SO_upload_16_dataProperties"
  "SO_upload_17_dataProp_Tree"
  "SO_upload_18_n_ary_relations_SQL"
  "SO_upload_19_n_ary_participants_SQL"
  "SO_upload_20_n_ary_data_assertions_SQL"
  "SO_upload_99_XMLtrailer"
)

echo "Source directory : $SRC_DIR"
echo "SQL directory    : $SQL_DIR"
echo "Output file      : $OUT_FILE"
echo "Files to process : ${#files[@]}"
echo

mkdir -p "$SQL_DIR"

# Copy/rename phase
for base in "${files[@]}"; do
  src="${SRC_DIR}/${base}.sql.txt"
  dst="${SQL_DIR}/${base}.sql"

  if [[ -f "$src" ]]; then
    cp -- "$src" "$dst"
    echo "Copied: $src -> $dst"
  else
    echo "Warning: missing source file, skipping: $src" >&2
  fi
done

# Concatenate phase
echo
echo "Concatenating files into: $OUT_FILE"
: > "$OUT_FILE"  # create/truncate

for base in "${files[@]}"; do
  part="${SQL_DIR}/${base}.sql"
  if [[ -f "$part" ]]; then
    cat -- "$part" >> "$OUT_FILE"
    printf "\n" >> "$OUT_FILE"  # optional newline between parts
    echo "Appended: $part"
  else
    echo "Skipping missing part: $part" >&2
  fi
done

echo
echo "    The generated SQL files (`date +"%Y-%m-%d %H:%M:%S"`):"
ls -al   $OUT_FILE

../OWLpreprocessing/cmd/DBupload.sh  localhost:3306 root Piros77Macska $OUT_FILE
