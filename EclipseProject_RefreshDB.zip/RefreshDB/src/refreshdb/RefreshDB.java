package refreshdb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *  the class renames and merges the generated .SQL files
 *  (composed by the project OWLpreprocessing) and upload
 *  the data into the DB... 
 */
public class RefreshDB 
{
    private String dirBase = "." ;
    private String cmdDir  = this.dirBase + "/cmd/" ;

	public static void main(String[] args) 
	{
  	    try
        {
  			new RefreshDB().execCommand(args) ;
        }
        catch(InterruptedException e)
        {
        	e.printStackTrace() ;
        }
		
	}   //  end of method main()
    
    private  void execCommand(String[] args) throws InterruptedException
    {
        if (args.length == 1) 
        {
        	this.dirBase = args[0] ;
            this.cmdDir  = this.dirBase + "/cmd/" ;
        }

        try
        {
        	String cmd = this.cmdDir + "copyAndRename.sh" ; 
        	
            ProcessBuilder pb = new ProcessBuilder(cmd) ;

            //  merge stdout and stderr
            pb.redirectErrorStream(true) ;

            Process process = pb.start();

            //  read the output
            try (BufferedReader reader = 
                 new BufferedReader(new InputStreamReader(process.getInputStream()))) 
            {
                String line;
                while ((line = reader.readLine()) != null) 
                {
                    System.out.println(line);
                }
            }
        } 
        catch(IOException e)
        {
            e.printStackTrace() ;
        }
        
    }   //  end of method execCommand()
	
}   //  end of class RefreshDB
