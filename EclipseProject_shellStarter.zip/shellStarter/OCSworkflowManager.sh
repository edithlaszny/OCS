#!/bin/bash

#+
#   TITLE:          OCSworkflowManager.sh
#   VERSION:        1-002
#
#   FACILITY:       Minimal control environment menu-system for
#                   the development pipeline of the OCS system.
#
#   AUTHOR          Edit Hlaszny, PhD (+36 30 3116516, edithlaszny@gmail.com) HED
#   SUPERVISED BY:  -
#   CREATION DATE:  21-SEP-2025
#   MODIFICATION HISTORY:
#       date        modified by
#       21-SEP-2025 HED   1-001 first draw
#       23-SEP-2025 HED   1-003 added diffs cmd names 


ROOT="$HOME/Desktop/OCS_test"
PROJECT_ROOT="$ROOT/EclipseOCSws"

VERSION="V. 1-002"
MODE=$1

if [ $# -ne 1 ] || [ "$1" != "academic" -a "$1" != "technical" ]; then
    echo "Usage: $(basename "$0")    academic | technical "
    exit 1
fi

_ActivateMenu()                         # parametrizable menusystem
{   #+
    #   input argument(s)
    #-
    _AMtitle=$1                         # menu-title
    _AMitem=$2                          # menu-name prefixes
    _AMcmd=$3                           # menu-command prefixes
    _AMmaxitem=$4                       # number of menu-items
    _AMlog=$5                           # yes | no : whether the selections shall logged
    _AMlogFunc=$6                       # subroutine's name of the log

    # GLobals set:  none
    # Globals used: _glbLogfile         - general logfile
    # Fix-coded:    some layout considerations

    if [ -z "$_AMlogFunc" ]             # if own log-function is undefined
    then
        _AMlogFunc="_WriteLog"          # the built-in one will be used
    fi

    while [ 1 ]     #  endless loop: exit by user's choice (if $_AMcmdNN is a return)
    do
        echo           ""
        echo           "  $_AMtitle"
        echo           ""
        if [ "$_AMlog" = "yes" -o "$_AMlog" = "YES" ]
        then
            $_AMlogFunc "  $_AMtitle"   I
        fi
        #+
        #   the first loop displays the menu-items
        #-
        _AMcnt=1
        while [ $_AMcnt -le $_AMmaxitem ]
        do
            _AMcurrentItem=$_AMitem$_AMcnt
            eval "_AMcurrentItem=\$${_AMcurrentItem}"
            _AMcurrentItem="  $_AMcnt   -   $_AMcurrentItem"

            echo            "$_AMcurrentItem"
            if [ "$_AMlog" = "yes" -o "$_AMlog" = "YES" ]
            then
                $_AMlogFunc "$_AMcurrentItem"   I
            fi

            _AMcnt=`expr $_AMcnt + 1`
        done

        _AManswer=0
        printf "\n  " ;  read   _AManswer
        #+
        #   the second one evaluates the user's choice
        #-
        _AMcnt=1
        while [ $_AMcnt -le $_AMmaxitem ]
        do
            if [ "$_AManswer" = "$_AMcnt" ]
            then
                _AMcurrentCmd=$_AMcmd$_AMcnt
                eval "_AMcurrentCmd=\$${_AMcurrentCmd}"
                echo
                break
            fi
            _AMcnt=`expr $_AMcnt + 1`
        done

        if [ $_AMcnt -gt $_AMmaxitem ]
        then
            #+
            #   an invalid choice
            #-
            _AMwarning="  invalid option, try again"
            echo           "$_AMwarning"
            if [ "$_AMlog" = "yes" -o "$_AMlog" = "YES" ]
            then
                $_AMlogFunc ">$_AManswer< $_AMwarning"   I
            fi
        else
            #+
            #   valid choice
            #-
            if [ "$_AMlog" = "yes" -o "$_AMlog" = "YES" ]
            then
                $_AMlogFunc "selected command: $_AMcurrentCmd"   I
            fi

            $_AMcurrentCmd              # execute selected command
        fi
    done

}   # end of _ActivateMenu()

launchDBcreation()
{
    $PROJECT_ROOT/CreaDBschema/cmd/createDBschema.sh

}   # end of launchProtege()

launchDBrefresh()
{
    $PROJECT_ROOT/RefreshDB/cmd/copyAndRename.sh

}   # end of launchProtege()

launchOntologyBrowser()
{
    BROWSER_X=100
    BROWSER_Y=100
    BROWSER_WIDTH=1050
    BROWSER_HEIGHT=1400

    echo "Launching ontology browser..."
    /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --app=file://$ROOT/data/OCS.html &
    sleep 2
    osascript -e "tell application \"Google Chrome\" to set bounds of front window to {$BROWSER_X, $BROWSER_Y, $BROWSER_WIDTH, $BROWSER_HEIGHT}"

}   # end of launchOntologyBrowser()

launchProtege()
{
    ontology="$ROOT/data/OCS.owl"
    echo "You can start Protégé (V. 5.6.3 is recommended) and open the file"
    echo "$ontology"

}   # end of launchProtege()

bold=$(tput bold)
normal=$(tput sgr0)

# Define menu items (these are the text labels shown to user)
if [ $MODE = "academic" ]
then
    menuTitle="    ${bold}Ontological Data Processing Workflow Manager${normal}"
    menuItem1="Initialize repository structure"
    menuItem2="Launch semantic preprocessing module"
    menuItem3="Integrate processed semantic data into repository"
    menuItem4="Execute schema transformation and output generation"
    menuItem5="Provide access to human-readable ontology interface"
    menuItem6="Provide access to formal ontology representation"
    menuItem7="${bold}EXIT SYSTEM${normal}"
else
    if [ $MODE = "technical" ]
    then
        menuTitle="    ${bold}Controlling the Computational Sociology Development Pipeline${normal}"
        menuItem1="Initialize database schema"
        menuItem2="Execute OWL preprocessing engine"
        menuItem3="Synchronize database with preprocessed OWL data"
        menuItem4="Generate OWL and HTML artifacts via DBFOschemafy"
        menuItem5="Display ontology browser interface URL (HTML)"
        menuItem6="Display ontology endpoint URL (OWL/XML format)"
        menuItem7="${bold}EXIT MENU${normal}"
    fi
fi

# Define commands to execute for each menu choice
menuCmd1="launchDBcreation"
menuCmd2="java -jar  $PROJECT_ROOT/OWLpreprocessing/jar/OWLpreproc.jar   ../OWLpreprocessing/"
menuCmd3="launchDBrefresh"
menuCmd4="java -jar  $PROJECT_ROOT/DBFOschemafy_3_0_1/jar/DBFO.jar"
menuCmd5="launchOntologyBrowser"
menuCmd6="launchProtege"
menuCmd7="return"

# Set up the menu parameters

menuItemPrefix="menuItem"     # prefix for menu item variables
menuCmdPrefix="menuCmd"       # prefix for command variables
maxItems=7                    # number of menu items
enableLogging="NO"            # use "NO" instead of "no" to avoid the -or bug
logFunction=""                # empty since logging is disabled

# Call the menu system
_ActivateMenu "$menuTitle"      \
              "$menuItemPrefix" \
              "$menuCmdPrefix"  \
              "$maxItems"       \
              "$enableLogging"  \
              "$logFunction"
echo "Exit from the menusystem..."
