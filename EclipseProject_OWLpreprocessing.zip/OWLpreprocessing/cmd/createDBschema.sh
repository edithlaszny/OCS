#!/bin/bash
#
# createDBschema.sh
#
# Simple script: create the DB (DBFOsociology) schema
# Environment: bash

set -euo pipefail

SRC_DIR="./output"
SQL_DIR="./sql"
OUT_FILE="${SQL_DIR}/_DBFOsociology.sql"

#
# DB schema creator
#     "SO_upload_06_disjoint_classes"
#
files=(
  "SO_create_00_DBFOsociology"
)

echo "Source directory : $SRC_DIR"
echo "SQL directory    : $SQL_DIR"
echo "Output file      : $OUT_FILE"
echo "Files to process : ${#files[@]}"
echo

mkdir -p "$SQL_DIR"

# Copy/rename phase
for base in "${files[@]}"; do
  src="${SRC_DIR}/${base}.sql.txt"
  dst="${SQL_DIR}/${base}.sql"

  if [[ -f "$src" ]]; then
    cp -- "$src" "$dst"
    echo "Copied: $src -> $dst"
  else
    echo "Warning: missing source file, skipping: $src" >&2
  fi
done

# Concatenate phase
echo
echo "Concatenating files into: $OUT_FILE"
: > "$OUT_FILE"  # create/truncate

for base in "${files[@]}"; do
  part="${SQL_DIR}/${base}.sql"
  if [[ -f "$part" ]]; then
    cat -- "$part" >> "$OUT_FILE"
    printf "\n" >> "$OUT_FILE"  # optional newline between parts
    echo "Appended: $part"
  else
    echo "Skipping missing part: $part" >&2
  fi
done

echo
echo "    The generated DB schema creator SQL files (`date +"%Y-%m-%d %H:%M:%S"`):"
ls -al   $OUT_FILE

./cmd/DBupload.sh  localhost:3306 root Piros77Macska $OUT_FILE
