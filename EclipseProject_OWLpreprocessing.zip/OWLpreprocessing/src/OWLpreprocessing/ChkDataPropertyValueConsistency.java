package OWLpreprocessing;

public class ChkDataPropertyValueConsistency 
{
	ChkDataPropertyValueConsistency() { ; }
	
    public boolean check(String data_property_value,
                         String data_property_type) 
    {
        if (data_property_value == null || data_property_type == null) return false;

        String v = data_property_value.trim();
        String t = data_property_type.trim();
    
        switch (t) 
        {
            case "xsd:string":
                return true; // any string (including empty) is valid
    
            case "xsd:boolean": 
            {
                // XML Schema booleans: true|false|1|0
                String s = v.toLowerCase();
                return s.equals("true") || s.equals("false") || s.equals("1") || s.equals("0");
            }
    
            case "xsd:int": 
            {
                try 
                {
                    int x = Integer.parseInt(v);
                    return true;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:long": 
            {
                try 
                {
                    long x = Long.parseLong(v);
                    return true;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:short": 
            {
                try 
                {
                    short x = Short.parseShort(v);
                    return true;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:integer": 
            {
                try 
                {
                    new java.math.BigInteger(v);
                    return true;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:negativeInteger": 
            {
                try 
                {
                    java.math.BigInteger bi = new java.math.BigInteger(v);
                    return bi.signum() < 0;
                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:unsignedInt": 
            {
                // 0 .. 4294967295
                try 
                {
                    java.math.BigInteger bi = new java.math.BigInteger(v);
                    return bi.signum() >= 0 &&
                           bi.compareTo(new java.math.BigInteger("4294967295")) <= 0;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:decimal": 
            {
                // Decimal without exponent per XML Schema
                // Regex: optional sign, digits, optional fractional part; no exponent

                return v.matches("[+-]?\\d+(?:\\.\\d+)?");
            }
    
            case "xsd:double":
            case "xsd:float": 
            {
                // Allow NaN, INF, -INF per XML Schema

                String s = v.toUpperCase();

                if (s.equals("NaN".toUpperCase()) || 
                    s.equals("INF") || 
                    s.equals("-INF"))   return true;
                try 
                {
                    Double.parseDouble(v); // also valid for float
                    return true;

                } catch (NumberFormatException e) { return false; }
            }
    
            case "xsd:date": 
            {
                // Expect ISO local date (YYYY-MM-DD)
                try 
                {
                    java.time.LocalDate.parse(v, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE);
                    return true;

                } catch (Exception e) { return false; }
            }
    
            case "xsd:dateTime": 
            {
                // Accept with offset (Z or ±HH:MM) or local date-time
                try 
                {
                    java.time.OffsetDateTime.parse(v, java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                    return true;

                } catch (Exception ignore) { }

                try 
                {
                    java.time.LocalDateTime.parse(v, java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                    return true;

                } catch (Exception ignore) { }

                try 
                {
                    java.time.Instant.parse(v); // e.g., 2025-09-14T05:43:08Z
                    return true;

                } catch (Exception e) { return false; }
            }
    
            case "xsd:gYear": 
            {
                // Year (allow optional leading sign, 4+ digits), no month/day
                return v.matches("[+-]?\\d{4,}");
            }
    
            case "xsd:language": 
            {
                // Simple BCP47-like: 1-8 letters, optional -subtags of 1-8 alphanum
                return v.matches("[a-zA-Z]{1,8}(-[a-zA-Z0-9]{1,8})*");
            }
    
            case "xsd:base64Binary": 
            {
                try 
                {
                    java.util.Base64.getDecoder().decode(v);
                    return true;

                } catch (IllegalArgumentException e) { return false; }
            }
    
            case "xsd:hexBinary": 
            {
                // Even number of hex digits
                return v.matches("(?i)[0-9a-f]*") && (v.length() % 2 == 0);
            }
    
            default:
                return false; // unknown type
        }
    
    }   //  end of method check()
	
}   /// end of class ChkDataPropertyValueConsistency 
