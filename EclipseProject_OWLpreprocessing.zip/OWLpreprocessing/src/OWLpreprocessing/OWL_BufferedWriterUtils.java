package OWLpreprocessing;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OWL_BufferedWriterUtils 
{
    private boolean silentMode = false ;
	
	public void closeBufferedWritablefile(BufferedWriter bw) 
    {
        try
        {
            if (bw != null)
            	bw.close();
        }
        catch (Exception finalEx)
        {
            System.out.println("Error in closing the BufferedWriter" + finalEx);
        }

    }   //  end of method closeBufferedWritablefile()

    
    public void writeSQLcommit(BufferedWriter bw) 
    {
    	String currTime  = getCurrTime() ; 
    	
    	ArrayList<String> trailer = new ArrayList<>();
    	trailer.add("") ;
    	trailer.add("COMMIT ;") ;
    	trailer.add("") ;
    	trailer.add("--  Current time: " + currTime) ;

    	writeBufferedWritablefile(bw, trailer) ;
    	
    }   //  end of method writeSQLcommit()

    
    public BufferedWriter createBufferedWritablefile(String outfileName) 
    {
    	BufferedWriter result = null ;
    	
        try 
        { 
        	result = new BufferedWriter(new FileWriter(new File(outfileName))) ;
        } 
        catch (IOException e) 
        { 
        	e.printStackTrace(); 
        }

    	return result ;
        
    }   //  end of method createBufferedWritablefile()

	
    public String getCurrTime() 
    {
    	String format = "yyyy-MM-dd HH:mm:ss.SSS" ;
    	return new SimpleDateFormat(format).format(new Date()) ;
    	
    }   //  end of method getCurrTime()


    public void writeBufferedWritablefile(BufferedWriter     bw,
    		                               ArrayList<String>  content) 
    {
    	content.stream() 
    	       .forEach(line -> { try { bw.write(line + "\n") ; }
                                  catch (IOException e) { e.printStackTrace(); }
        	                    } ) ;

    }   //  end of method writeBufferedWritablefile()
    
    
    /**
     *  Writes text message to the console
     *  @param logEntry displayed message  
     */
    public void log(String logEntry)
    {
        /*
        
        The param logEntry layout:
    
        <logEntry> ::= <spaces> <action> <spaces> <numericString> <spaces> <comment>
            <spaces> ::= <spaces> | <spaces> <space>
                <space> ::= { " "}
            <action> ::= { string_max_12_length_string }
            <numericString> ::= { ASCII_string_of_numeric_chars_max_length_is_12 }
            <comment> :: = { string_in_any_length }
    
        The displayed layout:
    
        <logEntry> ::= <action> { two_spaces } <formatted_numericString> { one_spaces } <comment>
            <action> ::= { string_max_12_length_string }
            <formatted_numericString> ::= { comme_separated_right_justified_numeric_string }
            <comment> :: = { string_in_any_length }
        */
    	
        if (!this.silentMode)
        {  
        	if (logEntry.charAt(0) == ' ')
        	{
//        	    Pattern LINE           = Pattern.compile("^\\s*([^\\s]{1,12})\\s+([0-9]{1,12})\\s+(.*)$");
//        	    Pattern LINE = Pattern.compile("^\\s*([^\\s]{1,15})\\s+([0-9]{1,12})\\s+(.*)$");

        	    
        	    Pattern LINE = Pattern.compile("^\\s*([^\\s]+)\\s+([0-9]{1,16})\\s+(.*)$");
        	    
        	    int NUMBER_FIELD_WIDTH = 8 ;
        	    
    	        String[] lines = logEntry.split("\\R", -1);
    	        for (String line : lines) 
    	        {
    	            Matcher m = LINE.matcher(line);
    	            if (m.matches()) 
    	            {
    	                String action  = m.group(1);
    	                String numStr  = m.group(2);
    	                String comment = m.group(3);

    	                try 
    	                {
    	                    long n = Long.parseLong(numStr);
    	                    String withCommas = String.format(Locale.US, "%,d", n);
    	                    
    	                    System.out.println("    " + action + "  " 
    	                            + String.format("%" + NUMBER_FIELD_WIDTH + "s", withCommas)
    	                            + " " + comment);
    	                } 
    	                catch (NumberFormatException e) 
    	                {
    	                    System.out.println("NumberFormatException" + e); // fallback unchanged
    	                }
    	            } 
    	            else 
    	            {
    	            	;  //  non-matching lines ignored
    	            }
    	            
    	        }   //  end of for loop
        	}	
            else
        	{
                System.out.print(logEntry) ;
        	}
        }
        
    }   //  end of method log()

}   //  end of class BufferedWriterUtils
