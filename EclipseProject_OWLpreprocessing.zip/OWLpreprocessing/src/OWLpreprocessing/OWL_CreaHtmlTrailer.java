package OWLpreprocessing ;

import java.io.BufferedWriter ;
import java.io.IOException ;
import java.nio.file.Files ;
import java.nio.file.Paths ;
import java.util.ArrayList;


public class OWL_CreaHtmlTrailer 
{
    /**
     * Common file handling methods
     */
    private OWL_BufferedWriterUtils bwu       = new OWL_BufferedWriterUtils() ;
    private int                 itemCount = 0 ;

    public OWL_CreaHtmlTrailer(String DBname,
                             String HtmlTrailerCommandsIN_txt, 
    		                 String HtmlTrailerCommandsOUT_SQL) 
    {
        writeXMLtrailer(DBname,
                        HtmlTrailerCommandsIN_txt, 
		                HtmlTrailerCommandsOUT_SQL) ;
    }

    /**
     * Reads the SKOS annotation file and generates SQL output.
     * The input file consists of rows with the structure, e.g.:
     * <p>  skos:Concept
     *      skos:example
     *      skos:note
     *
     * @param inputFilename  The path to the input .txt file.
     * @param outputFilename The path to the output .sql.txt file.
     */
    private void writeXMLtrailer(String DBname,
                                 String inFile, 
    		                     String outFile) 
    {
        try (BufferedWriter bw = bwu.createBufferedWritablefile(outFile)) 
        {
        	
            ArrayList<String> h = new ArrayList<>() ;
            
            h.add("/*") ; 
            h.add("    Title:       " + outFile)  ;
            h.add("    Description: Generating HTML trailer in SQL format") ;
            h.add("    Format:      OWL/XML encoding") ;
            h.add("    Written by:  Java class " + this.getClass().getSimpleName()) ;
            h.add("    Date:        " + bwu.getCurrTime()) ;
            h.add(" */") ; 
            h.add("") ; 
            h.add("USE   " + DBname + " ;") ;
            h.add("") ; 
            h.add("SET   TRANSACTION READ WRITE ;") ;
            h.add("START TRANSACTION ;") ; 
            
            bwu.writeBufferedWritablefile(bw, h) ;

            Files.lines(Paths.get(inFile))
                 .forEach(line -> 
                 {
                     String htmlCommand_SQL = String.format(
                            "\nINSERT INTO HTML_TRAILER (html_cmd)\n" +
                            "VALUES (" +
                            "\'%s\'" + ") ;\n", line) ;
                     try 
                     {
                         bw.write(htmlCommand_SQL) ;
                     } 
                     catch (IOException e) 
                     {
                         e.printStackTrace() ;
                     }
                     
                     incrementItemCount() ;
                 }
                         ) ;
                         
            bwu.writeSQLcommit(bw) ;
        } 
        catch (IOException e) 
        {
            e.printStackTrace() ;
        }
        
        /**
         *  Logging of the result
         */
        bwu.log(new StringBuilder()
                    .append("    asserted  " + this.itemCount + " html header item(s)\n")
                    .toString()
               ) ;

    }   //  end of method writeXMLheader()
    
    
    private void incrementItemCount()
    {
	    this.itemCount++ ;
    }
  
}   //  end of class CreateHtmlTrailer()
