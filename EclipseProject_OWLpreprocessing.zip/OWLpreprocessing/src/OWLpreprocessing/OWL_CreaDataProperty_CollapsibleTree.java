package OWLpreprocessing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.ListIterator;

public class OWL_CreaDataProperty_CollapsibleTree {

    private OWL_BufferedWriterUtils bwu = new OWL_BufferedWriterUtils() ;
    private String                  DBname = null ;
	
	OWL_CreaDataProperty_CollapsibleTree(String DBname,
			                             String dataPropertyDefs,
			                             String dataPropertyTreeSQLdefs
			                            )
	{
        this.DBname = DBname ;
        
		writeSQLfileHdr(dataPropertyTreeSQLdefs) ;

        ArrayList<String> content = new ArrayList<>() ;
        content.add("<h2>SO data property structure</h2>") ;
        content.add("<div class=\"BFOstruct\">") ;
        content.add("    <details>") ;
        content.add("    <summary>owl:topDataProperty</summary>" ) ;

        addSQLlines(dataPropertyTreeSQLdefs, content) ;

        ListIterator<String> itr = evalDataPropertyDefs(dataPropertyDefs).listIterator();            
        
        while (itr.hasNext())
        {
            String dpName = itr.next();
            String htmlCmd =   "    <details><summary><a href=\"#" 
                              + dpName + "\">" + dpName + "</a></summary></details>" ;
            content.clear() ; 
            content.add(htmlCmd) ;
            
            addSQLlines(dataPropertyTreeSQLdefs, content) ;
        	
        }   //  end of while-loop

        content.clear() ; 
        
        content.add("    </details>") ;
        content.add("    <br />") ;
        content.add("</div>") ;
        content.add("<hr />") ;
        addSQLlines(dataPropertyTreeSQLdefs, content) ;
        
        addSQLcontentAndClose(dataPropertyTreeSQLdefs, "\nCOMMIT ;\n") ;
        
	}   //  end of constructor

    private ArrayList<String> evalDataPropertyDefs(String inFileName)  
    {
    	/**
    	 *  Now, in this case the data property structure is single-level: 
    	 *  if this changes, the this method is already needed. THAT is why 
    	 *  I chose to create an ArrayList of data property names and generate 
    	 *  SQL content from it...
    	 */
    	
        ArrayList<String> result = new ArrayList<>();

        Path path = Path.of(inFileName);
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) 
        {
            String line;
            while ((line = reader.readLine()) != null) 
            {
                String trimmedLine = line.trim();
 
                if (trimmedLine.isEmpty() || trimmedLine.startsWith("#")) 
                	continue;

                String dataPropertyName = trimmedLine.substring(0, trimmedLine.indexOf(" ")) ;
                result.add(dataPropertyName);
            }
        }
        catch (IOException e) { e.printStackTrace() ; }

        return result;
        
    }   //  end of method evalDataPropertyDefs()

    private void writeSQLfileHdr(String outFile)
    {
    	String  description = "The SQL file contains ~50 data property names\n" +
                              "                 encoded in html, for collapsible tree" ;
    	String  content = 
    			"/*\n" +          
                "    Title:       " + outFile + "\n" +         
                "    Description: " + description + "\n" +         
                "    Written by:  Java class " + this.getClass().getSimpleName() + "\n" +         
                "    Date:        " + bwu.getCurrTime() + "\n" +         
                " */ \n" +          
                "USE   " + this.DBname + " ; \n" +         
                "\n" +          
                "SET   TRANSACTION READ WRITE ; \n" +         
                "START TRANSACTION ; \n" ;         

    	//                              appendMode
    	addSQLcontent(outFile, content, false) ;
    	
    }   //  end of method writeSQLfileHdr()
    
	private void addSQLcontent(String SQLfile, String content, boolean appendMode)
	{
        try  
        {
        	FileWriter fw = new FileWriter(new File(SQLfile), appendMode) ;

            fw.write(content) ;
            fw.flush();
        }
        catch (IOException e) { e.printStackTrace() ; }
		
	}   //  end of method addSQLcontent()

	private void addSQLcontentAndClose(String SQLfile, String content)
	{
        try  
        {
        	FileWriter fw = new FileWriter(new File(SQLfile), true) ;

            fw.write(content) ;
            fw.flush();
            fw.close() ;
        }
        catch (IOException e) { e.printStackTrace() ; }
		
	}   //  end of method addSQLcontentAndClose()

    private void addSQLlines(String SQLfile, ArrayList<String> content)
    {
        ListIterator<String> itr = content.listIterator();

        while (itr.hasNext())
        {
            String SQLcmd = "INSERT INTO DATA_PROPERTY_TREE (html_cmd) VALUES ('" + itr.next() + "') ;\n" ;

            addSQLcontent(SQLfile, SQLcmd, true) ;
        }

    }   //  end of method addSQLlines()
	
}   //  end of class OWL_CreaDataProperty_CollapsibleTree
