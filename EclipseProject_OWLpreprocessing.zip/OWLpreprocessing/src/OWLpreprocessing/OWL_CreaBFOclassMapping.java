package OWLpreprocessing ;

import java.io.* ;
import java.nio.file.* ;
import java.util.* ;

public class OWL_CreaBFOclassMapping
{
    private int itemCount = 0 ;
	
	OWL_CreaBFOclassMapping(String DBname, 
			              String inFile, 
			              String outFile) 
    {
        OWL_BufferedWriterUtils u          = new OWL_BufferedWriterUtils() ;

        try (BufferedWriter w = u.createBufferedWritablefile(outFile)) 
        {
            ArrayList<String> h = new ArrayList<>() ;
            
            h.add("/*") ; 
            h.add("    Title:       " + outFile)  ;
            h.add("    Description: Generating BFO classes/subclasses in SQL format") ;
            h.add("    Written by:  Java class " + this.getClass().getSimpleName()) ;
            h.add("    Date:        " + u.getCurrTime()) ;
            h.add(" */") ; 
            h.add("") ; 
            h.add("USE   " + DBname + " ;") ;
            h.add("") ; 
            h.add("SET   TRANSACTION READ WRITE ;") ;
            h.add("START TRANSACTION ;") ; 
            h.add("") ;
            
            u.writeBufferedWritablefile(w, h) ;

            Files.lines(Paths.get(inFile)).filter(l->!l.trim().isEmpty())
                 .map(l->l.trim().split("\\s+",2))
                 .forEach(p->{ try { 
                	                 if (p[1].charAt(0) != '-') 
                	                 {
                	                 String superClass = p[1].substring(0, 11) ;
                	                	 
                	                 w.write("INSERT INTO OWL_CLASSES (class_IRI, " + 
                                             "superclass_of_IRI, class_individual_count, " +
                                             "annotated)\nVALUES ('" + p[0] + "', '"+ superClass + "', " +
                                             "0, TRUE) ;\n\n") ;
                	                 }

                                   } catch(IOException e)
                                   {
                                	   e.printStackTrace() ;
                                   }
                      
                 
                 incrementItemCount() ;
                }) ;

            u.writeSQLcommit(w) ;
        } 
        catch(IOException e)
        {
        	e.printStackTrace() ;
        }
        
        /**
         *  Logging of the result
         */
        u.log(new StringBuilder()
                  .append("    asserted  " + this.itemCount + " BFO mappings(s)\n")
                  .toString()
              ) ;
        
    }   //  end of constructor

        
    private void incrementItemCount()
    {
    	this.itemCount++ ;
    }
      
	
}   //  end of class CreateBFOclassMapping 
