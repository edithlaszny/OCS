package OWLpreprocessing;

import java.io.BufferedWriter;
// import java.io.File;
// import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
// import java.text.SimpleDateFormat;
import java.util.ArrayList;
// import java.util.Date;

public class OWL_CreaOWLclassAnnotation 
{
	/**
	 *  'endOfClassName' is the separator between 
	 *  OWL class name and its annotation
	 */
	private  char   endOfClassName = '=' ;
	
	/**
	 *  The official SKOS definition, explaining the meaning of a class or property.
	 */
	private  String SKOSdef = "skos:definition" ;
	
	/**
	 *  Default language is English
	 */
	private  String defaultLanguage = "en" ;
	
	/**
	 *  common file handling methods
	 */
	private  OWL_BufferedWriterUtils bwu       = new OWL_BufferedWriterUtils() ;
    private int                  itemCount = 0 ;
	
	OWL_CreaOWLclassAnnotation(String DBname,
			                 String infileName, 
			                 String outfileName)
	
	{
		BufferedWriter          bw = this.bwu.createBufferedWritablefile(outfileName) ;
    	
    	writeSQLheader(DBname,  bw) ;
    	writeSQL_INSERTcmd(     bw, infileName) ;
		
    	this.bwu.writeSQLcommit(bw) ;		
		this.bwu.closeBufferedWritablefile(bw);
		
        /**
         *  Logging of the result
         */
        bwu.log(new StringBuilder()
                    .append("    asserted  " + this.itemCount + " OWL class annotation(s)\n")
                    .toString()
               ) ;
    	
	}   //  and of method constructor()

	
    private void generateSQL_INSERTcmd(BufferedWriter bw, String line) 
    {
		int    separatorPosition = line.indexOf(endOfClassName) ;
    	String className  = line.substring(0, separatorPosition - 1 ) ;
        String annotation = line.substring(separatorPosition + 1, line.length()) ;		
    	
    	ArrayList<String> content = new ArrayList<>();
		content.add("INSERT INTO  CLASS_ANNOTATIONS (class_IRI, " +
    	                    "annotation_type_IRI, language, annotation)") ;
        content.add("VALUES ('" + className + "' ,") ;
        content.add("        '" + SKOSdef   + "' ,") ;
        content.add("        '" + defaultLanguage   + "' ,") ;
        content.add("        '" + annotation.trim() + "'") ;
        content.add("       ) ;") ;
		
        this.bwu.writeBufferedWritablefile(bw, content) ;
        
        incrementItemCount() ;
    	
    }   //  end of generateSQL_INSERTcmd()
    

    private void writeSQL_INSERTcmd(BufferedWriter bw, String infileName) 
    {
        try 
        { 
        	Files.lines(Paths.get(infileName))
        	     .forEach(line -> generateSQL_INSERTcmd(bw, line) ) ; 
        } 
        catch (IOException e) 
        { 
        	e.printStackTrace(); 
        }

    }   //  end of method writeSQL_INSERTcmd()
    
    
    private void writeSQLheader(String DBname, BufferedWriter bw) 
    {
    	String currTime  = this.bwu.getCurrTime() ; 
    	String className = this.getClass().getSimpleName() ; 
    	
    	ArrayList<String> hdr = new ArrayList<>();
		hdr.add("/*") ;
    	hdr.add("    Title:       SO_upload_02_class_annotations.sql"                ) ;
    	hdr.add("    Description: Generating OWL class annotation in SQL format"  ) ;
    	hdr.add("    Written by:  Java class " + className ) ;
    	hdr.add("    Date:        " + currTime ) ;
    	hdr.add(" */") ;
    	hdr.add("") ;
    	hdr.add("USE   " + DBname + " ;") ;
    	hdr.add("") ;
    	hdr.add("SET   TRANSACTION READ WRITE ;") ;
        hdr.add("START TRANSACTION ;") ;
    	hdr.add("") ;

    	this.bwu.writeBufferedWritablefile(bw, hdr) ;
    	
    }   //  end of method writeSQLheader()

    
    private void incrementItemCount()
    {
    	this.itemCount++ ;
    }
    
}   //  end of class CreateOWLclassAnnotation
