package OWLpreprocessing;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class RunTimeCalculator 
{
    /*    
    public static void main(String[] args) {
        // Your timestamps
        String startTime = "2025-09-14 05:43:01.351";
        String endTime = "2025-09-14 05:43:08.381";
        
        long runtimeMs = calculateRuntime(startTime, endTime);
        
        System.out.println("Start time: " + startTime);
        System.out.println("End time:   " + endTime);
        System.out.println("Runtime:    " + runtimeMs + " milliseconds");
        System.out.println("Runtime:    " + (runtimeMs / 1000.0) + " seconds");
    }
    */
    
    /**
     * Calculates runtime in milliseconds between two timestamps
     * @param startTime Start timestamp in format "yyyy-MM-dd HH:mm:ss.SSS"
     * @param endTime End timestamp in format "yyyy-MM-dd HH:mm:ss.SSS"
     * @return Runtime in milliseconds
     */
    public long calculateRuntime(String startTime, String endTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
        
        LocalDateTime start = LocalDateTime.parse(startTime, formatter);
        LocalDateTime end = LocalDateTime.parse(endTime, formatter);
        
        return ChronoUnit.MILLIS.between(start, end);
    }
    
    /**
     * Alternative method using System.currentTimeMillis() for real-time measurement
     * @param startMillis Start time in milliseconds since epoch
     * @param endMillis End time in milliseconds since epoch
     * @return Runtime in milliseconds
     */
    public long calculateRuntime(long startMillis, long endMillis) {
        return endMillis - startMillis;
    }
    
    /**
     * Method to measure runtime of a code block
     * Usage example:
     * long start = System.currentTimeMillis();
     * // your code here
     * long runtime = measureRuntime(start);
     */
    public long measureRuntime(long startMillis) {
        return System.currentTimeMillis() - startMillis;
    }
    
    /**
     * Formats runtime in milliseconds to seconds with 3 decimal places
     * @param runtimeMs Runtime in milliseconds
     * @return Formatted string like "7.124 sec"
     */
    public String formatRuntimeToSec(long runtimeMs) {
        double seconds = runtimeMs / 1000.0;
        return String.format("%.3f", seconds);
    }
    
    /**
     * Alternative formatting method with custom decimal places
     * @param runtimeMs Runtime in milliseconds
     * @param decimalPlaces Number of decimal places (e.g., 3 for "7.124")
     * @return Formatted string like "7.124 sec"
     */
    public String formatRuntime(long runtimeMs, int decimalPlaces) {
        double seconds = runtimeMs / 1000.0;
        String format = "%." + decimalPlaces + "f sec";
        return String.format(format, seconds);
    }
    
    public String getCurrTime() 
    {
    	String format = "yyyy-MM-dd HH:mm:ss.SSS" ;
    	return new SimpleDateFormat(format).format(new Date()) ;
    	
    }   //  end of method getCurrTime()
    
}
