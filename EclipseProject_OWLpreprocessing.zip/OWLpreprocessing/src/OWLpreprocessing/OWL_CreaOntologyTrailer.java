package OWLpreprocessing ;

import java.io.BufferedWriter ;
import java.io.IOException ;
import java.nio.file.Files ;
import java.nio.file.Paths ;
import java.util.ArrayList;


public class OWL_CreaOntologyTrailer 
{
    /**
     * Common file handling methods
     */
    private OWL_BufferedWriterUtils bwu       = new OWL_BufferedWriterUtils() ;
    private int                 itemCount = 0 ;

    public OWL_CreaOntologyTrailer(String DBname,
    		                     String XMLtrailerCommandsIN, 
    		                     String XMLtrailerCommandsOUT) 
    {
        writeXMLtrailer(DBname,
        		        XMLtrailerCommandsIN, 
        		        XMLtrailerCommandsOUT) ;
    }

    /**
     *  Reads the tailer definition file and generates SQL output.
     *  The input file consists of rows with the structure OWL/XML 
     *  encoded phrases
     *
     * @param inputFilename  The path to the input .txt file.
     * @param outputFilename The path to the output .sql.txt file.
     */
    private void writeXMLtrailer(String DBname,
    		                     String inFile, 
    		                     String outFile) 
    {
        try (BufferedWriter bw = bwu.createBufferedWritablefile(outFile)) 
        {
        	
            ArrayList<String> h = new ArrayList<>() ;
            
            h.add("/*") ; 
            h.add("    Title:       " + outFile)  ;
            h.add("    Description: Generating ontology XML trailer in SQL format") ;
            h.add("    Format:      OWL/XML encoding") ;
            h.add("    Written by:  Java class " + this.getClass().getSimpleName()) ;
            h.add("    Date:        " + bwu.getCurrTime()) ;
            h.add(" */") ; 
            h.add("") ; 
            h.add("USE   " + DBname + " ;") ;
            h.add("") ; 
            h.add("SET   TRANSACTION READ WRITE ;") ;
            h.add("START TRANSACTION ;") ; 
            
            bwu.writeBufferedWritablefile(bw, h) ;

            Files.lines(Paths.get(inFile))
                 .forEach(line -> 
                 {
                     String annotationSQL = String.format(
                            "\nINSERT INTO ONTOLOGY_TRAILER (xml_cmd)\n" +
                            "VALUES (" +
                            "\'%s\'" + ") ;\n", line) ;
                     try 
                     {
                         bw.write(annotationSQL) ;
                     } 
                     catch (IOException e) 
                     {
                         e.printStackTrace() ;
                     }
                     
                     incrementItemCount() ;
                 }
                         ) ;
                         
            bwu.writeSQLcommit(bw) ;
        } 
        catch (IOException e) 
        {
            e.printStackTrace() ;
        }
        
        /**
         *  Logging of the result
         */
        bwu.log(new StringBuilder()
                    .append("    asserted  " + this.itemCount + " trailer item(s)\n")
                    .toString()
               ) ;

    }   //  end of method writeXMLtrailer()
    
    
    private void incrementItemCount()
    {
	    this.itemCount++ ;
    }
  
}   //  end of class CreateOntologyTrailer()
