package OWLpreprocessing;

import java.io.IOException ;
import java.nio.file.Files ;
import java.nio.file.Paths ;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;
import java.util.Map;


public class OWL_EvalObjectPropertyAttributes 
{
    /**
     * Common file handling methods
     */
    private OWL_BufferedWriterUtils bwu        = new OWL_BufferedWriterUtils() ;
    private int                 itemCount  = 0 ;
    
    private Map<String, String> objPropAttribs = new HashMap<>(); 

    
    OWL_EvalObjectPropertyAttributes()
	{
    	;
	}
    
    OWL_EvalObjectPropertyAttributes(String objPropertyAttributes)
	{
		try
		{
            Files.lines(Paths.get(objPropertyAttributes))
            .forEach(line -> { 
            	                 if (line.charAt(0) != '#')
            	                 {
            	                	 processAttributeLine(line, objPropertyAttributes) ;
              	                     itemCount++ ;
            	                 }
                             }
                    ) ;
		}
        catch (IOException e) { e.printStackTrace() ; }

	    //  Logging of the result
	    bwu.log(new StringBuilder()
	                .append("    asserted  " + this.itemCount * 7 + 
	                		" object attributes\n")
	                .toString()
	           ) ;
	    
	}   //  end of constructor

    private void processAttributeLine(String line, String filename)
    {
        Pattern pattern = Pattern.compile("^(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)$");
        Matcher matcher = pattern.matcher(line);

        if (matcher.find()) 
        {
            String objPropName = matcher.group(1); 
            String funct       = matcher.group(2); 
            String invFunct    = matcher.group(3); 
            String symm        = matcher.group(4); 
            String aSymm       = matcher.group(5); 
            String trans       = matcher.group(6); 
            String refl        = matcher.group(7); 
            String irRefl      = matcher.group(8); 
            
            if (attributeIsOK(funct)    &&
                attributeIsOK(invFunct) &&
                attributeIsOK(symm)     &&
                attributeIsOK(aSymm)    &&
                attributeIsOK(trans)    &&
                attributeIsOK(refl)     &&
                attributeIsOK(irRefl)
               )
            {
                String SQLcmdFragment =  funct       + ", " +
                                         invFunct    + ", " +
                                         symm        + ", " +
                                         aSymm       + ", " +
                                         trans       + ", " +
                                         refl        + ", " +
                                         irRefl      + "  " ;
                
                //                      key          value
            	this.objPropAttribs.put(objPropName, SQLcmdFragment);
            }
            else
            {	
                System.err.println("1 Fatal error in the file " + filename + 
 			           ",- line number " + ++itemCount + ".\n") ;
             	System.exit(-1);
            }
        }
        else
        {
        	System.err.println("2 Fatal error in the file " + filename + 
        			           ",- line number " + ++itemCount + ".\n") ;
        	System.err.println("line >" + line + "<") ;
        	
        	System.exit(-1);
        }
        
    }   //  end of method processAttributeLine()

    private boolean attributeIsOK(String attribute)
    {
    	if (attribute.compareTo("true")  == 0 ||
    	    attribute.compareTo("false") == 0)
    		return true ;
    	else
    		return false ;
    	
    }   //  end of method attributeIsOK()
    
    
    public String getSQLattributeFragment(String objPropName)
    {
    	String SQLattributeFragment = "false, false, false, false, false, false, false" ;
    	
        if (this.objPropAttribs.containsKey(objPropName)) 
        {
        	SQLattributeFragment = this.objPropAttribs.get(objPropName) ;
        }
        
        return SQLattributeFragment ;
    	
    }   //  end of method getSQLattributeFragment()
    
}   //  end of class EvaluateObjectPropertyAttributes
    
