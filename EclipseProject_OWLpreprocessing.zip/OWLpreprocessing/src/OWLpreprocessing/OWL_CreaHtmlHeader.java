package OWLpreprocessing ;

import java.io.BufferedWriter ;
import java.io.IOException ;
import java.nio.file.Files ;
import java.nio.file.Paths ;
import java.util.ArrayList;

public class OWL_CreaHtmlHeader 
{
    /**
     * Common file handling methods
     */
    private OWL_BufferedWriterUtils bwu       = new OWL_BufferedWriterUtils() ;
    private int                     itemCount = 0 ;

    public OWL_CreaHtmlHeader(String DBname,
                            String HtmlHeaderCommandsIN_1_txt, 
                            String HtmlHeaderCommandsIN_2_txt, 
    		                String HtmlHeaderCommandsOUT_SQL) 
    {
        writeXMLheader(DBname,
           		       HtmlHeaderCommandsIN_1_txt, 
		               HtmlHeaderCommandsIN_2_txt, 
        		       HtmlHeaderCommandsOUT_SQL) ;
    }

    /**
     * Reads the SKOS annotation file and generates SQL output.
     * The input file consists of rows with the structure, e.g.:
     * <p>  skos:Concept
     *      skos:example
     *      skos:note
     *
     * @param inputFilename  The path to the input .txt file.
     * @param outputFilename The path to the output .sql.txt file.
     */
    private void writeXMLheader(String DBname,
                                String inFile_1, 
                                String inFile_2, 
    		                    String outFile) 
    {
        try (BufferedWriter bw = bwu.createBufferedWritablefile(outFile)) 
        {
        	
            ArrayList<String> h = new ArrayList<>() ;
            
            h.add("/*") ; 
            h.add("    Title:       " + outFile)  ;
            h.add("    Description: Generating HTML header in SQL format") ;
            h.add("    Format:      OWL/XML encoding") ;
            h.add("    Written by:  Java class " + this.getClass().getSimpleName()) ;
            h.add("    Date:        " + bwu.getCurrTime()) ;
            h.add(" */") ; 
            h.add("") ; 
            h.add("USE   " + DBname + " ;") ;
            h.add("") ; 
            h.add("SET   TRANSACTION READ WRITE ;") ;
            h.add("START TRANSACTION ;") ; 
            
            bwu.writeBufferedWritablefile(bw, h) ;

            Files.lines(Paths.get(inFile_1))
            .forEach(line -> 
            {
                String annotationSQL = String.format(
                       "\nINSERT INTO HTML_HEADER (html_cmd, session_id)\n" +
                       "VALUES (" +
                       "\'%s\'" + ", " + 1 + ") ;\n", line) ;
                try 
                {
                    bw.write(annotationSQL) ;
                } 
                catch (IOException e) 
                {
                    e.printStackTrace() ;
                }
                
                incrementItemCount() ;
            }
                    ) ;
                    
            Files.lines(Paths.get(inFile_2))
            .forEach(line -> 
            {
                String annotationSQL = String.format(
                       "\nINSERT INTO HTML_HEADER (html_cmd, session_id)\n" +
                       "VALUES (" +
                       "\'%s\'" + ", " + 2 + ") ;\n", line) ;
                try 
                {
                    bw.write(annotationSQL) ;
                } 
                catch (IOException e) 
                {
                    e.printStackTrace() ;
                }
                
                incrementItemCount() ;
            }
                    ) ;
                    
            bwu.writeSQLcommit(bw) ;
        } 
        catch (IOException e) 
        {
            e.printStackTrace() ;
        }
        
        /**
         *  Logging of the result
         */
        bwu.log(new StringBuilder()
                    .append("    asserted  " + this.itemCount + " html header item(s)\n")
                    .toString()
               ) ;

    }   //  end of method writeXMLheader()
    
    
    private void incrementItemCount()
    {
	    this.itemCount++ ;
    }
  
}   //  end of class CreateHtmlHeader()
