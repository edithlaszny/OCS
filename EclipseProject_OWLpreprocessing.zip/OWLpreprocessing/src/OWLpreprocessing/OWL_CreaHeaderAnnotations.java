package OWLpreprocessing ;

import java.io.BufferedWriter ;
import java.io.IOException ;
import java.nio.file.Files ;
import java.nio.file.Paths ;
import java.util.ArrayList;


public class OWL_CreaHeaderAnnotations 
{
    /**
     * Common file handling methods
     */
    private OWL_BufferedWriterUtils bwu       = new OWL_BufferedWriterUtils() ;
    private int                 itemCount = 0 ;

    public OWL_CreaHeaderAnnotations(String DBname,
    		                       String headerAnnotationsIn, 
    		                       String headerAnnotationsOut) 
    {
        writeHeaderAnnotations(DBname,
        		               headerAnnotationsIn, 
        		               headerAnnotationsOut) ;
    }

    /**
     * Reads the annotation file and generates XML output.
     * The input file consists of rows with the structure:
     * <p>
     *        "<annotation_property>" "<literal_value>"
     *
     * @param inputFilename  The path to the input file.
     * @param outputFilename The path to the output file.
     */
    private void writeHeaderAnnotations(String DBname,
    		                            String inFile, 
    		                            String outFile) 
    {
        try (BufferedWriter bw = bwu.createBufferedWritablefile(outFile)) 
        {
            ArrayList<String> h = new ArrayList<>() ;
            
            h.add("/*") ; 
            h.add("    Title:       " + outFile)  ;
            h.add("    Description: Generating ontology header annotations in SQL format") ;
            h.add("    Written by:  Java class " + this.getClass().getSimpleName()) ;
            h.add("    Date:        " + bwu.getCurrTime()) ;
            h.add(" */") ; 
            h.add("") ; 
            h.add("USE   " + DBname + " ;") ;
            h.add("") ; 
            h.add("SET   TRANSACTION READ WRITE ;") ;
            h.add("START TRANSACTION ;") ; 
            
            bwu.writeBufferedWritablefile(bw, h) ;
        	
            Files.lines(Paths.get(inFile))
                 .filter(line -> !line.trim().isEmpty())
                 .map(line -> line.trim().split("\\s+", 2))
                 .forEach(parts -> 
                 {
                     if (parts.length == 2)      //  property, htmlEquivalent, literal
                     {
                         /**
                          *  Remove quotes from the parsed parts
                          */
                         String property = parts[0].replace("\"", "") ;
                         String literal = parts[1].replace("\"", "") ;
                         
                         String annotationSQL = String.format(
                             "\nINSERT INTO ONTOLOGY_HEADER_ANNOTATIONS (iri, literal)\n" +
                             "VALUES (" +
                             "\'%s\'" + ", " + "\'%s\'" + ") ;\n", property, literal
                                                             ) ;
                         try 
                         {
                             bw.write(annotationSQL) ;
                         } 
                         catch (IOException e) 
                         {
                             e.printStackTrace() ;
                         }
                     }

                     incrementItemCount() ;
                 }
                         ) ;
            
            bwu.writeSQLcommit(bw) ;
        } 
        catch (IOException e) 
        {
            e.printStackTrace() ;
        }

        /**
         *  Logging of the result
         */
        bwu.log(new StringBuilder()
                    .append("    asserted  " + this.itemCount + " header annotation(s)\n")
                    .toString()
               ) ;
        
    }   //  end of method writeHeaderAnnotations()
    
    
    private void incrementItemCount()
    {
    	this.itemCount++ ;
    }
    
}   //  end of class CreateHeaderAnnotations()

